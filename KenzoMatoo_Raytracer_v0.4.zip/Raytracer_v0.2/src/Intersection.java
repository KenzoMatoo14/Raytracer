public class Intersection {
    private double t;             // Distance from ray origin to intersection
    private Vector3D point;       // Intersection point in 3D space
    private Vector3D normal;      // Surface normal at intersection
    private Object3D object;      // Object that was hit

    // Constructor
    public Intersection(double t, Vector3D point, Vector3D normal, Object3D object) {
        this.t = t;
        this.point = point;
        this.normal = normal.normalize(); // Ensure normal is unit-length
        this.object = object;
    }

    // Getters
    public double getT() {
        return t;
    }

    public Vector3D getPoint() {
        return point;
    }

    public Vector3D getNormal() {
        return normal;
    }

    public Object3D getObject() {
        return object;
    }

    @Override
    public String toString() {
        return String.format("Intersection at %s with normal %s (t=%.2f)", point, normal, t);
    }
}
