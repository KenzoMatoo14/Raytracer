public class Ray {
    private Vector3D origin;
    private Vector3D direction;

    // Constructor
    public Ray(Vector3D origin, Vector3D direction) {
        this.origin = origin;
        this.direction = direction.normalize(); // Ensure it's a unit vector
    }

    // Getter methods
    public Vector3D getOrigin() {
        return origin;
    }

    public Vector3D getDirection() {
        return direction;
    }

    // Compute a point along the ray at distance 't'
    public Vector3D getPoint(double t) {
        return origin.add(direction.multiply(t));
    }

    @Override
    public String toString() {
        return String.format("Ray(Origin: %s, Direction: %s)", origin, direction);
    }
}
