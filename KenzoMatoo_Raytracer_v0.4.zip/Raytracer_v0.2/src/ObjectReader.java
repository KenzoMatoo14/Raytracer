import java.io.*;
import java.util.*;
import java.awt.*;
import java.util.List;

public class ObjectReader {

    public static Model3D readOBJ(String filename, Vector3D position, Color color) {
        List<Vector3D> vertices = new ArrayList<>();
        List<Triangle> triangles = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;

            while ((line = reader.readLine()) != null) {
                line = line.trim();

                if (line.startsWith("v ")) {
                    // Parse a vertex
                    String[] tokens = line.split("\\s+");
                    double x = Double.parseDouble(tokens[1]);
                    double y = Double.parseDouble(tokens[2]);
                    double z = Double.parseDouble(tokens[3]);
                    vertices.add(new Vector3D(x, y, z));
                } else if (line.startsWith("f ")) {
                    String[] params  = line.split("\\s+");
                    int vertexCount = params.length - 1;

                    int[] faceVertices = new int[vertexCount];
                    for (int i = 1; i < params.length; i++) {
                        faceVertices[i - 1] = Integer.parseInt(params[i].split("[/]+")[0]) - 1;
                    }

                    Vector3D v0 = vertices.get(faceVertices[0]);
                    Vector3D v1 = vertices.get(faceVertices[1]);
                    Vector3D v2 = vertices.get(faceVertices[2]);

                    triangles.add(new Triangle(v0, v1, v2, color));

                    // If it's a quad (4 vertices), split into second triangle (v0, v2, v3)
                    if (vertexCount == 4) {
                        Vector3D v3 = vertices.get(faceVertices[3]);
                        triangles.add(new Triangle(v0, v2, v3, color));
                    }
                }
            }

        } catch (IOException e) {
            System.err.println("Failed to read OBJ file: " + e.getMessage());
        }

        Triangle[] triangleArray = triangles.toArray(new Triangle[0]);
        return new Model3D(position, triangleArray, color);
    }
}
