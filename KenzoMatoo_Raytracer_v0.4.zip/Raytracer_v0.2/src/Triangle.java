import java.awt.*;

public class Triangle extends Object3D {
    public static final double EPSILON = 1e-6;
    private Vector3D[] vertices;
    private Vector3D normal;

    public Triangle(Vector3D v0, Vector3D v1, Vector3D v2, Color color) {
        super(calculateCentroid(v0, v1, v2), color);
        this.vertices = new Vector3D[]{v0, v1, v2};
        this.normal = v1.subtract(v0).cross(v2.subtract(v0)).normalize();
    }

    private static Vector3D calculateCentroid(Vector3D v0, Vector3D v1, Vector3D v2) {
        return new Vector3D(
                (v0.getX() + v1.getX() + v2.getX()) / 3.0,
                (v0.getY() + v1.getY() + v2.getY()) / 3.0,
                (v0.getZ() + v1.getZ() + v2.getZ()) / 3.0
        );
    }

    public Vector3D[] getVertices() {
        return vertices;
    }

    public Vector3D getNormal() {
        return normal;
    }

    @Override
    public Intersection intersect(Ray ray) {
        Vector3D v0 = vertices[0], v1 = vertices[1], v2 = vertices[2];

        Vector3D edge1 = v1.subtract(v0);
        Vector3D edge2 = v2.subtract(v0);
        Vector3D rayDir = ray.getDirection();
        Vector3D h = rayDir.cross(edge2);
        double determinant = edge1.dot(h);

        // If determinant is near zero, ray is parallel to triangle
        if (Math.abs(determinant) < EPSILON) return null;

        double invDet = 1.0 / determinant;
        Vector3D s = ray.getOrigin().subtract(v0);
        double u = invDet * s.dot(h);

        if (u < 0.0 || u > 1.0) return null;

        Vector3D q = s.cross(edge1);
        double v = invDet * rayDir.dot(q);

        if (v < 0.0 || (u + v) > 1.0) return null;

        double t = invDet * edge2.dot(q);

        if (t > EPSILON) {
            Vector3D intersectionPoint = ray.getOrigin().add(rayDir.multiply(t));
            return new Intersection(t, intersectionPoint, normal, this);
        }

        return null;
    }
}
