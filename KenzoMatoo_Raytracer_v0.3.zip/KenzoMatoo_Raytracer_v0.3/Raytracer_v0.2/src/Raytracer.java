import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Raytracer {

    private Scene scene;
    private Camera camera;

    // Constructor
    public Raytracer(Scene scene, Camera camera) {
        this.scene = scene;
        this.camera = camera;
    }

    // Trace a single ray and return a color
    public Color traceRay(Ray ray) {
        Intersection intersection = scene.intersect(ray, camera.getNear(), camera.getFar());

        if (intersection == null) {
            return Color.WHITE; // Placeholder: Object hit → Color it red
        }

        // Get object color
        Vector3D objectColor = intersection.getObject().getColor();

        // Convert Vector3D (RGB 0-1) to Java Color (RGB 0-255)
        return new Color(
                (float) Math.max(0, Math.min(objectColor.x, 1)),
                (float) Math.max(0, Math.min(objectColor.y, 1)),
                (float) Math.max(0, Math.min(objectColor.z, 1))
        );
    }

    // Render the scene and save to an image
    public void render(int width, int height, String filename) {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        System.out.println("Rendering scene...");

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                double normX = (double) x / (width - 1);
                double normY = (double) y / (height - 1);

                Ray ray = camera.generateRay(normX, normY);
                Color color = traceRay(ray);

                image.setRGB(x, y, color.getRGB());
            }
        }

        // Save image to file
        try {
            File output = new File(filename);
            ImageIO.write(image, "png", output);
            System.out.println("Image saved as " + filename);
        } catch (IOException e) {
            System.err.println("Failed to save image: " + e.getMessage());
        }
    }


    // Main method to run the raytracer
    public static void main(String[] args) {
        // Create a scene
        Scene scene = new Scene();

        // Define camera parameters
        Vector3D cameraPos = new Vector3D(0, 0, 0);
        Vector3D lookAt = new Vector3D(0, 0, -1);
        Vector3D up = new Vector3D(0, 1, 0);
        double fov = 90;  // Field of view in degrees
        double aspectRatio = 1; // Example: width / height (adjust as needed)
        double near = 0.1;  // Near plane (prevent extreme closeness)
        double far = 50.0;

        // Create a camera at (0,0,0) looking towards -Z
        Camera camera = new Camera(cameraPos, lookAt, up, fov, aspectRatio, near, far);

        // Add objects to the scene (Positioned to match the reference image)
        scene.addObject(new Sphere(new Vector3D(0, 3, -10), 1, new Vector3D(1, 0, 0))); // Larger red sphere
        scene.addObject(new Sphere(new Vector3D(6, 4, -12), 1, new Vector3D(0, 0, 1)));
        scene.addObject(new Triangle(new Vector3D(0, 4, -6), new Vector3D(5, 3, -8), new Vector3D(4, 8, -10), new Vector3D(0, 1, 0)));// Larger blue sphere

        // Create raytracer
        Raytracer raytracer = new Raytracer(scene, camera);
        // Render and save to an image
        raytracer.render(400, 400, "output.png");
    }
}
