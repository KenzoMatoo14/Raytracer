public class Triangle extends Object3D {
    private Vector3D v0, v1, v2;
    private Vector3D normal;

    public Triangle(Vector3D v0, Vector3D v1, Vector3D v2, Vector3D color) {
        super(color);
        this.v0 = v0;
        this.v1 = v1;
        this.v2 = v2;
        this.normal = v1.subtract(v0).cross(v2.subtract(v0)).normalize();
    }

    @Override
    public Intersection intersect(Ray ray) {
        Vector3D edge1 = v1.subtract(v0);
        Vector3D edge2 = v2.subtract(v0);
        Vector3D h = ray.getDirection().cross(edge2);
        double a = edge1.dot(h);

        // If determinant is near zero, ray is parallel to triangle
        if (Math.abs(a) < 1e-6) return null;

        double f = 1.0 / a;
        Vector3D s = ray.getOrigin().subtract(v0);
        double u = f * s.dot(h);

        if (u < 0.0 || u > 1.0) return null;

        Vector3D q = s.cross(edge1);
        double v = f * ray.getDirection().dot(q);

        if (v < 0.0 || (u + v) > 1.0) return null;

        double t = f * edge2.dot(q);

        if (t > 1e-6) { 
            Vector3D intersectionPoint = ray.getOrigin().add(ray.getDirection().multiply(t));
            return new Intersection(t, intersectionPoint, normal, this);
        }

        return null;
    }
}
