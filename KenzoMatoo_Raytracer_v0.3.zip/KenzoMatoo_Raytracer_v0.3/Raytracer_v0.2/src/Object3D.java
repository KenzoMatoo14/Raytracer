public abstract class Object3D {
    protected Vector3D color;

    public Object3D(Vector3D color) {
        this.color = color;
    }

    public Vector3D getColor() {
        return color;
    }

    // Abstract method for intersection (must be implemented by child classes)
    public abstract Intersection intersect(Ray ray);
}
