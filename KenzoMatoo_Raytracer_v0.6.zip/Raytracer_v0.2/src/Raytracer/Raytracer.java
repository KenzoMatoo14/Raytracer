package Raytracer;

import Raytracer.Objects.DirectionalLight;
import Raytracer.Objects.Light;
import Raytracer.Objects.Model3D;
import Raytracer.Objects.Triangle;

import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import static java.lang.Math.clamp;

public class Raytracer {

    private Scene scene;
    private Camera camera;

    // Constructor
    public Raytracer(Scene scene, Camera camera) {
        this.scene = scene;
        this.camera = camera;
    }

    // Trace a single ray and return a color
    public Color traceRay(Ray ray) {
        Intersection intersection = scene.intersect(ray, camera.getNear(), camera.getFar());

        if (intersection != null) {
            Color objColor = intersection.getObject().getColor();

            double[] objColors = new double[]{
                    objColor.getRed() / 255.0,
                    objColor.getGreen() / 255.0,
                    objColor.getBlue() / 255.0
            };

            double[] finalColor = new double[3];

            for (Light light : scene.getLights()) {
                double nDotL = light.getNDotL(intersection);
                double intensity = light.getIntensity() * nDotL;

                Color lightColor = light.getColor();
                double[] lightColors = new double[]{
                        lightColor.getRed() / 255.0,
                        lightColor.getGreen() / 255.0,
                        lightColor.getBlue() / 255.0
                };

                for (int i = 0; i < 3; i++) {
                    finalColor[i] += objColors[i] + lightColors[i] * intensity;
                }
            }

            return new Color(
                    (float) clamp(finalColor[0], 0.0, 1.0f),
                    (float) clamp(finalColor[1], 0.0, 1.0f),
                    (float) clamp(finalColor[2], 0.0, 1.0f)
            );
        }

        return Color.BLACK;
    }

    // Render the scene and save to an image
    public void render(int width, int height, String filename) {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        System.out.println("Rendering scene...");

        long rayStart = System.nanoTime();
        int rayCount = 0;

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                double normX = (double) x / (width - 1);
                double normY = (double) y / (height - 1);

                Ray ray = camera.generateRay(normX, normY);
                Color color = traceRay(ray);
                rayCount++;

                image.setRGB(x, y, color.getRGB());
            }
        }

        long rayEnd = System.nanoTime();
        System.out.printf("Ray generation + intersection time: %.3f s\n", (rayEnd - rayStart) / 1e9);
        System.out.printf("Total rays traced: %d\n", rayCount);

        System.out.println("Total triangle tests: " + Triangle.triangleTests);
        System.out.println("Avg triangle tests per ray: " + ((double) Triangle.triangleTests / rayCount));


        // Save image to file
        try {
            File output = new File(filename);
            ImageIO.write(image, "png", output);
            System.out.println("Image saved as " + filename);
        } catch (IOException e) {
            System.err.println("Failed to save image: " + e.getMessage());
        }
    }


    // Main method to run the raytracer
    public static void main(String[] args) {
        long startTotal = System.nanoTime();


        // Create a scene
        long startSceneSetup = System.nanoTime();
        Scene scene = new Scene();

        // Define camera parameters
        Vector3D cameraPos = new Vector3D(0, 0, 0);
        Vector3D lookAt = new Vector3D(0, 0, -1);
        Vector3D up = new Vector3D(0, 1, 0);
        double fov = 60;  // Field of view in degrees
        double aspectRatio = 1; // Example: width / height (adjust as needed)
        double near = 0.1;  // Near plane (prevent extreme closeness)
        double far = 400;

        // Create a camera at (0,0,0) looking towards -Z
        Camera camera = new Camera(cameraPos, lookAt, up, fov, aspectRatio, near, far);

        long endSceneSetup = System.nanoTime();
        System.out.printf("Scene setup time: %.3f s\n", (endSceneSetup - startSceneSetup) / 1e9);

        long startOBJ = System.nanoTime();

        // Add objects to the scene (Positioned to match the reference image)

        //scene.addObject(new Sphere(new Vector3D(0, 3, -10), 1, Color.RED)); // Larger red sphere
        //scene.addObject(new Sphere(new Vector3D(6, 4, -12), 1, Color.BLUE));// Larger blue sphere

        /*
        scene.addObject(new Triangle(
                new Vector3D(0, 4, -6),
                new Vector3D(5, 3, -8),
                new Vector3D(4, 8, -10),
                Color.GREEN));
        scene.addObject(new Triangle(
                new Vector3D(0, 4, -6),
                new Vector3D(5, 3, -8),
                new Vector3D(2, 2, -10),
                Color.GREEN));
        */

        /*
        scene.addObject(new Model3D(
                new Vector3D(0, 0, -7),
                new Triangle[]{
                        new Triangle(
                                new Vector3D(0, 4, -6),
                                new Vector3D(5, 3, -8),
                                new Vector3D(4, 8, -10),
                                Color.GREEN),
                        new Triangle(
                                new Vector3D(0, 4, -6),
                                new Vector3D(5, 3, -8),
                                new Vector3D(2, 2, -8),
                                Color.GREEN)},
                Color.GREEN));
         */


        /*
        String pathToOBJ = "src/Raytracer/Models/Ring.obj"; // adjust as needed
        Vector3D modelPosition = new Vector3D(0, -2, -5);  // where to place the model
        Color modelColor = Color.RED;

        Model3D model = ObjectReader.readOBJ(pathToOBJ, modelPosition, modelColor);
        scene.addObject(model);

        String pathToOBJ1 = "src/Raytracer/Models/Cube.obj"; // adjust as needed
        Vector3D modelPosition1 = new Vector3D(0, 2, -5);  // where to place the model
        Color modelColor1 = Color.RED;

        Model3D model1 = ObjectReader.readOBJ(pathToOBJ1, modelPosition1, modelColor1);
        scene.addObject(model1);

        String pathToOBJ2 = "src/Raytracer/Models/CubeQuad.obj"; // adjust as needed
        Vector3D modelPosition2 = new Vector3D(2, 0, -5);  // where to place the model
        Color modelColor2 = Color.GREEN;

        Model3D model2 = ObjectReader.readOBJ(pathToOBJ2, modelPosition2, modelColor2);
        scene.addObject(model2);
         */

        /*
        String pathToOBJ3 = "src/Raytracer/Models/SmallTeapot.obj"; // adjust as needed
        Vector3D modelPosition3 = new Vector3D(-2, 0, -5);  // where to place the model
        Color modelColor3 = Color.BLUE;

        Model3D model3 = ObjectReader.readOBJ(pathToOBJ3, modelPosition3, modelColor3);
        scene.addObject(model3);
         */

        /*
        String pathToOBJ4 = "src/Raytracer/Models/hand.obj"; // adjust as needed
        Vector3D modelPosition4 = new Vector3D(-30, 0, -40);  // where to place the model
        Color modelColor4 = Color.RED;

        Model3D model4 = ObjectReader.readOBJ(pathToOBJ4, modelPosition4, modelColor4);
        scene.addObject(model4);
         */

        String pathToOBJ5 = "src/Raytracer/Models/Glass.obj"; // adjust as needed
        Vector3D modelPosition5 = new Vector3D(-.5, -.5, -2.5);  // where to place the model
        Color modelColor5 = Color.GRAY;

        Model3D model5 = ObjectReader.readOBJ(pathToOBJ5, modelPosition5, modelColor5);
        scene.addObject(model5);

        long endOBJ = System.nanoTime();
        System.out.printf("OBJ Loading time: %.3f s\n", (endOBJ - startOBJ) / 1e9);

        scene.addLight(new DirectionalLight(new Vector3D(0, 0, -1), Color.WHITE, .5));

        long startBVH = System.nanoTime();
        scene.buildBVH();
        long endBVH = System.nanoTime();
        System.out.printf("BVH build time: %.3f s\n", (endBVH - startBVH) / 1e9);

        // Create raytracer
        Raytracer raytracer = new Raytracer(scene, camera);

        // Render and save to an image
        long startRender = System.nanoTime();
        raytracer.render(800, 800, "output.png");
        long endRender = System.nanoTime();
        System.out.printf("Rendering time: %.3f s\n", (endRender - startRender) / 1e9);

        long endTotal = System.nanoTime();
        System.out.printf("Total execution time: %.3f s\n", (endTotal - startTotal) / 1e9);
    }
}
