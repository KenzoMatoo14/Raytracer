public class Camera {
    private Vector3D position; // Camera position in 3D space
    private Vector3D forward;  // Direction the camera is facing
    private Vector3D right;    // Rightward direction (perpendicular to forward)
    private Vector3D up;       // Upward direction

    private double fov;        // Field of view in degrees
    private double aspectRatio; // Aspect ratio (width/height)

    // Constructor
    public Camera(Vector3D position, Vector3D lookAt, Vector3D up, double fov, double aspectRatio) {
        this.position = position;
        this.forward = lookAt.subtract(position).normalize();
        this.right = this.forward.cross(up).normalize();
        this.up = this.right.cross(this.forward).normalize();
        this.fov = Math.toRadians(fov); // Convert to radians
        this.aspectRatio = aspectRatio;
    }

    // Generate a ray for a given pixel coordinate (x, y) in normalized device coordinates [-1,1]
    public Ray generateRay(double x, double y) {
        double scale = Math.tan(fov / 2); // Scale factor based on field of view
        double pixelX = (2 * x - 1) * aspectRatio * scale; // Scale x to viewport
        double pixelY = (1 - 2 * y) * scale; // Flip y-axis for correct image orientation

        // Compute ray direction
        Vector3D rayDirection = forward
                .add(right.multiply(pixelX))
                .add(up.multiply(pixelY))
                .normalize();

        return new Ray(position, rayDirection);
    }

    // Getters
    public Vector3D getPosition() {
        return position;
    }

    public Vector3D getForward() {
        return forward;
    }
}
