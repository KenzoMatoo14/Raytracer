import java.util.ArrayList;
import java.util.List;

public class Scene {
    private List<Object3D> objects; // List of objects in the scene

    // Constructor
    public Scene() {
        this.objects = new ArrayList<>();
    }

    // Add an object to the scene
    public void addObject(Object3D object) {
        objects.add(object);
    }

    // Find the closest intersection between a ray and objects in the scene
    public Intersection intersect(Ray ray) {
        Intersection closestIntersection = null;
        double minDistance = Double.POSITIVE_INFINITY;

        for (Object3D object : objects) {
            Intersection intersection = object.intersect(ray);
            if (intersection != null && intersection.getT() < minDistance) {
                minDistance = intersection.getT();
                closestIntersection = intersection;
            }
        }

        return closestIntersection; // Returns null if no intersection is found
    }

    // Get all objects in the scene
    public List<Object3D> getObjects() {
        return objects;
    }
}
