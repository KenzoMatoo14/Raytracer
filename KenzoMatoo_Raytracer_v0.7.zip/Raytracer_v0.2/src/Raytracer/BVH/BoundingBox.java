package Raytracer.BVH;


import Raytracer.Ray;
import Raytracer.Vector3D;

public class BoundingBox {
    public Vector3D min;
    public Vector3D max;
    public static final double EPSILON = 1e-8;

    public BoundingBox(Vector3D min, Vector3D max) {
        this.min = min;
        this.max = max;
    }

    // Crea una caja contenedora de dos cajas
    public static BoundingBox union(BoundingBox a, BoundingBox b) {
        Vector3D newMin = new Vector3D(
                Math.min(a.min.getX(), b.min.getX()),
                Math.min(a.min.getY(), b.min.getY()),
                Math.min(a.min.getZ(), b.min.getZ())
        );
        Vector3D newMax = new Vector3D(
                Math.max(a.max.getX(), b.max.getX()),
                Math.max(a.max.getY(), b.max.getY()),
                Math.max(a.max.getZ(), b.max.getZ())
        );
        return new BoundingBox(newMin, newMax);
    }

    public Vector3D getCentroid() {
        // Average min and max coordinates using vector operations
        return this.min.add(this.max).divide(2);
    }

    // Intersección de rayo con la caja usando el método slab
    public boolean intersect(Ray ray, double tMin, double tMax) {
        for (int i = 0; i < 3; i++) {
            double origin = ray.getOrigin().get(i);
            double dir = ray.getDirection().get(i);

            if (Math.abs(dir) < EPSILON) {
                // Ray is parallel to the slab
                if (origin < min.get(i) || origin > max.get(i)) return false;
            } else {

                double invD = 1.0 / dir;
                double t0 = (min.get(i) - origin) * invD;
                double t1 = (max.get(i) - origin) * invD;

                if (invD < 0.0) {
                    double tmp = t0;
                    t0 = t1;
                    t1 = tmp;
                }

                tMin = Math.max(tMin, t0);
                tMax = Math.min(tMax, t1);

                if (tMax <= tMin) return false;
            }
        }
        return true;
    }
}
