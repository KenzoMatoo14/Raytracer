package Raytracer.BVH;

import Raytracer.Intersection;
import Raytracer.Objects.Object3D;
import Raytracer.Ray;
import Raytracer.Vector3D;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class BVHNode {
    private static final int MAX_OBJECTS_PER_LEAF = 2;
    private int splitAxis;

    private BoundingBox bounds;
    private BVHNode left;
    private BVHNode right;
    private List<Object3D> objects; // hojas

    public BVHNode(List<Object3D> objs) {
        build(objs);
    }

    private void build(List<Object3D> objs) {
        this.bounds = computeBounds(objs);

        if (objs.size() <= MAX_OBJECTS_PER_LEAF) {
            this.objects = objs;
            return;
        }

        // Determine split axis based on box extent
        Vector3D extent = bounds.max.subtract(bounds.min);
        int axis;
        if (extent.getX() > extent.getY() && extent.getX() > extent.getZ()) {
            axis = 0; // X
        } else if (extent.getY() > extent.getZ()) {
            axis = 1; // Y
        } else {
            axis = 2; // Z
        }

        // Sort objects along the chosen axis
        this.splitAxis = axis;
        objs.sort(Comparator.comparingDouble(o -> o.getPosition().get(splitAxis)));

        // Split into two halves
        int mid = objs.size() / 2;
        List<Object3D> leftObjs = new ArrayList<>(objs.subList(0, mid));
        List<Object3D> rightObjs = new ArrayList<>(objs.subList(mid, objs.size()));

        this.left = new BVHNode(leftObjs);
        this.right = new BVHNode(rightObjs);
    }

    private BoundingBox computeBounds(List<Object3D> objs) {
        BoundingBox box = objs.get(0).getBoundingBox();
        for (int i = 1; i < objs.size(); i++) {
            box = BoundingBox.union(box, objs.get(i).getBoundingBox());
        }
        return box;
    }

    public Intersection intersect(Ray ray, double tMin, double tMax) {
        if (!bounds.intersect(ray, tMin, tMax)) return null;

        if (objects != null) {
            Intersection closest = null;
            double closestT = tMax;

            for (Object3D obj : objects) {
                Intersection hit = obj.intersect(ray);
                if (hit != null && hit.getT() < closestT) {
                    closest = hit;
                    closestT = hit.getT();
                }
            }
            return closest;
        }

        BVHNode first = left;
        BVHNode second = right;

        // Determine which child to check first based on ray direction
        double mid = (left.bounds.min.get(splitAxis) + left.bounds.max.get(splitAxis)) * 0.5;
        if (ray.getDirection().get(splitAxis) > 0) {
            first = left;
            second = right;
        } else {
            first = right;
            second = left;
        }

        Intersection hit1 = first.intersect(ray, tMin, tMax);
        if (hit1 != null) {
            Intersection hit2 = second.intersect(ray, tMin, hit1.getT());
            return (hit2 != null && hit2.getT() < hit1.getT()) ? hit2 : hit1;
        }

        return second.intersect(ray, tMin, tMax);
    }
}
