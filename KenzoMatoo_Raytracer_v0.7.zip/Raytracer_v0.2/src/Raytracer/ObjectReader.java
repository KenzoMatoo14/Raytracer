package Raytracer;

import java.io.*;
import java.util.*;
import java.awt.*;
import java.util.List;

import Raytracer.Objects.Model3D;
import Raytracer.Objects.Triangle;


public class ObjectReader {

    public static Model3D readOBJ(String filename, Vector3D position, Color color) {
        List<Vector3D> vertices = new ArrayList<>();
        List<Vector3D> normals = new ArrayList<>();
        List<Triangle> triangles = new ArrayList<>();

        int currentSmoothingGroup = 0;

        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;

            while ((line = reader.readLine()) != null) {
                line = line.trim();

                if (line.startsWith("v ")) {
                    // Parse a vertex
                    String[] tokens = line.split("\\s+");
                    double x = Double.parseDouble(tokens[1]);
                    double y = Double.parseDouble(tokens[2]);
                    double z = Double.parseDouble(tokens[3]);
                    vertices.add(new Vector3D(x, y, z));

                } else if (line.startsWith("vn ")) {
                    // Vertex normal
                    String[] tokens = line.split("\\s+");
                    double x = Double.parseDouble(tokens[1]);
                    double y = Double.parseDouble(tokens[2]);
                    double z = Double.parseDouble(tokens[3]);
                    normals.add(new Vector3D(x, y, z));

                } else if (line.startsWith("s ")) {
                    // Smoothing group
                    String[] tokens = line.split("\\s+");
                    currentSmoothingGroup = tokens[1].equals("off") ? 0 : Integer.parseInt(tokens[1]);

                } else if (line.startsWith("f ")) {
                    String[] params  = line.split("\\s+");

                    int vertexCount = params.length - 1;
                    int[] vIndices = new int[vertexCount];
                    int[] nIndices = new int[vertexCount];

                    for (int i = 1; i < params.length; i++) {
                        String[] parts = params[i].split("[/]+");
                        vIndices[i - 1] = Integer.parseInt(parts[0]) - 1;
                        if (parts.length >= 3 && !parts[2].isEmpty()) {
                            nIndices[i - 1] = Integer.parseInt(parts[2]) - 1;
                        } else {
                            nIndices[i - 1] = -1; // No normal
                        }
                    }

                    Vector3D v0 = vertices.get(vIndices[0]);
                    Vector3D v1 = vertices.get(vIndices[1]);
                    Vector3D v2 = vertices.get(vIndices[2]);

                    if (nIndices[0] >= 0 && currentSmoothingGroup > 0) {
                        Vector3D n0 = normals.get(nIndices[0]);
                        Vector3D n1 = normals.get(nIndices[1]);
                        Vector3D n2 = normals.get(nIndices[2]);
                        triangles.add(new Triangle(v0, v1, v2, n0, n1, n2, color));
                    } else {
                        triangles.add(new Triangle(v0, v1, v2, color));
                    }

                    // If it's a quad (4 vertices), split into second triangle (v0, v2, v3)
                    if (vertexCount == 4) {
                        Vector3D v3 = vertices.get(vIndices[3]);
                        if (nIndices[0] >= 0 && currentSmoothingGroup > 0) {
                            Vector3D n2 = normals.get(nIndices[2]);
                            Vector3D n3 = normals.get(nIndices[3]);
                            Vector3D n0 = normals.get(nIndices[0]);
                            triangles.add(new Triangle(v0, v2, v3, n0, n2, n3, color));
                        } else {
                            triangles.add(new Triangle(v0, v2, v3, color));
                        }
                    }
                }
            }

        } catch (IOException e) {
            System.err.println("Failed to read OBJ file: " + e.getMessage());
        }

        Triangle[] triangleArray = triangles.toArray(new Triangle[0]);
        return new Model3D(position, triangleArray, color);
    }
}
