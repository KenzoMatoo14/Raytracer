package Raytracer;

import Raytracer.BVH.BVHNode;
import Raytracer.Objects.Light;
import Raytracer.Objects.Object3D;

import java.util.ArrayList;
import java.util.List;

public class Scene {
    private List<Object3D> objects; // List of objects in the scene
    private List<Light> lights;
    private BVHNode bvhRoot = null; // Optional, for acceleration

    // Constructor
    public Scene() {
        this.objects = new ArrayList<>();
        this.lights = new ArrayList<>();
    }

    // Add an object to the scene
    public void addObject(Object3D object) {
        objects.add(object);
    }

    // Get all objects in the scene
    public List<Object3D> getObjects() {
        return objects;
    }

    public void addLight(Light light) {
        lights.add(light);
    }

    // Get all lights in the scene
    public List<Light> getLights() {
        return lights;
    }

    // Build BVH from added objects (should be called once after setup)
    public void buildBVH() {
        this.bvhRoot = new BVHNode(objects);
    }

    // Find the closest intersection between a ray and objects in the scene
    public Intersection intersect(Ray ray, double near, double far) {
        if (bvhRoot != null) {
            return bvhRoot.intersect(ray, near, far);
        }

        Intersection closestIntersection = null;
        double minDistance = Double.POSITIVE_INFINITY;

        for (Object3D object : objects) {
            Intersection intersection = object.intersect(ray);
            if (intersection != null) {
                double t = intersection.getT();
                // Check if intersection is within near and far plane
                if (t >= near && t <= far && t < minDistance) {
                    minDistance = t;
                    closestIntersection = intersection;
                }
            }
        }

        return closestIntersection; // Returns null if no intersection is found
    }

}
