package Raytracer.Objects;

import java.awt.*;

import Raytracer.BVH.BoundingBox;
import Raytracer.Intersection;
import Raytracer.Ray;
import Raytracer.Vector3D;

public class Sphere extends Object3D {
    private double radius;

    public Sphere(Vector3D center, double radius, Color color) {
        super(center, color);
        this.radius = radius;
    }

    public Vector3D getCenter() {
        return getPosition();
    }

    public double getRadius() {
        return radius;
    }

    @Override
    public Intersection intersect(Ray ray) {
        Vector3D center = getPosition();
        Vector3D L = center.subtract(ray.getOrigin()); // L = C - O
        double tca = L.dot(ray.getDirection()); // tca = L · D

        if (tca < 0) return null;  // Sphere is behind the ray, no intersection

        double d2 = L.dot(L) - tca * tca; // d² = L·L - tca²
        double radius2 = radius * radius;

        if (d2 > radius2) return null; // No intersection

        double thc = Math.sqrt(radius2 - d2); // thc = sqrt(radius² - d²)
        double t0 = tca - thc;
        double t1 = tca + thc;

        double t = (t0 > 0) ? t0 : (t1 > 0 ? t1 : -1);
        if (t < 0) return null; // No valid intersection

        // Compute intersection point and normal
        Vector3D intersectionPoint = ray.getPoint(t);
        Vector3D normal = intersectionPoint.subtract(center).normalize();

        return new Intersection(t, intersectionPoint, normal, this);
    }

    @Override
    public BoundingBox getBoundingBox() {
        Vector3D center = getCenter();
        double r = getRadius();
        Vector3D min = new Vector3D(center.getX() - r, center.getY() - r, center.getZ() - r);
        Vector3D max = new Vector3D(center.getX() + r, center.getY() + r, center.getZ() + r);
        return new BoundingBox(min, max);
    }

    @Override
    public String toString() {
        return String.format("Sphere(Center: %s, Radius: %.2f, Color: %s)", getCenter(), radius, getColor());
    }
}
