package Raytracer.Objects;

import Raytracer.Intersection;
import Raytracer.Vector3D;

import java.awt.*;

public class PointLight extends Light {

    public PointLight(Vector3D position, Color color, double intensity) {
        super(position, color, intensity);
    }

    @Override
    public double getNDotL(Intersection intersection) {
        // Light direction is from surface point to light position
        Vector3D L = getPosition().subtract(intersection.getPoint()).normalize(); // L = lightPos - surfacePos
        return Math.max(intersection.getNormal().dot(L), 0.0);
    }
}
