package Raytracer.Objects;

import Raytracer.BVH.BoundingBox;
import Raytracer.Intersection;
import Raytracer.Ray;
import Raytracer.Vector3D;

import java.awt.Color;

public abstract class Light extends Object3D {
    private double intensity;

    public Light(Vector3D Position, Color color, double intensity) {
        super(Position, color);
        setIntensity(intensity);
    }

    public double getIntensity() {
        return intensity;
    }

    public void setIntensity(double intensity) {
        this.intensity = intensity;
    }

    public abstract double getNDotL(Intersection intersection);

    @Override
    public Intersection intersect(Ray ray) {
        return new Intersection(-1, Vector3D.ZERO(), Vector3D.ZERO(), null);
    }

    @Override
    public BoundingBox getBoundingBox() {
        // Lights are not part of the BVH — so this won't be used
        return new BoundingBox(Vector3D.ZERO(), Vector3D.ZERO());
    }
}
