package Raytracer.Objects;

import Raytracer.BVH.BoundingBox;
import Raytracer.Intersection;
import Raytracer.Ray;
import Raytracer.Vector3D;

import java.awt.*;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Model3D extends Object3D {
    private List<Triangle> triangles;

    public Model3D(Vector3D position, Triangle[] triangles, Color color) {
        super(position, color);
        setTriangles(triangles);
    }

    public List<Triangle> getTriangles() {
        return triangles;
    }

    public void setTriangles(Triangle[] triangles) {
        Vector3D position = getPosition();
        Set<Vector3D> uniqueVertices = new HashSet<>();
        for(Triangle triangle : triangles){
            uniqueVertices.addAll(Arrays.asList(triangle.getVertices()));
        }

        for(Vector3D vertex : uniqueVertices){
            vertex.setX(vertex.getX() + position.getX());
            vertex.setY(vertex.getY() + position.getY());
            vertex.setZ(vertex.getZ() + position.getZ());
        }
        this.triangles = Arrays.asList(triangles);
    }

    @Override
    public Intersection intersect(Ray ray) {
        double distance = -1;
        Vector3D closestPosition = Vector3D.ZERO();
        Vector3D closestNormal = Vector3D.ZERO();

        for(Triangle triangle : getTriangles()){
            Intersection intersection = triangle.intersect(ray);
            if (intersection != null) {
                double intersectionDistance = intersection.getT();
                if (intersectionDistance > 0 && (intersectionDistance < distance || distance < 0)) {
                    distance = intersectionDistance;
                    closestPosition = ray.getOrigin().add(ray.getDirection().multiply(distance));
                    closestNormal = intersection.getNormal();
                }
            }
        }

        if(distance == -1){
            return null;
        }

        return new Intersection(distance, closestPosition, closestNormal, this);
    }

    @Override
    public BoundingBox getBoundingBox() {
        if (triangles == null || triangles.isEmpty()) {
            return null;
        }

        Vector3D min = new Vector3D(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
        Vector3D max = new Vector3D(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY);

        for (Triangle triangle : triangles) {
            for (Vector3D vertex : triangle.getVertices()) {
                min = Vector3D.min(min, vertex);
                max = Vector3D.max(max, vertex);
            }
        }

        return new BoundingBox(min, max);
    }
}