package Raytracer.Objects;

import Raytracer.BVH.BoundingBox;
import Raytracer.Intersection;
import Raytracer.Ray;
import Raytracer.Vector3D;

import java.awt.*;

public class Triangle extends Object3D {
    public static final double EPSILON = 1e-6;
    private Vector3D[] vertices;
    private Vector3D[] normals;
    private final Vector3D edge1, edge2;
    private final Vector3D faceNormal;
    public static long triangleTests = 0;

    public Triangle(Vector3D v0, Vector3D v1, Vector3D v2, Vector3D n0, Vector3D n1, Vector3D n2, Color color) {
        super(calculateCentroid(v0, v1, v2), color);
        this.vertices = new Vector3D[]{v0, v1, v2};
        this.edge1 = v1.subtract(v0);
        this.edge2 = v2.subtract(v0);
        this.faceNormal = edge1.cross(edge2).normalize();

        this.normals = new Vector3D[]{
                n0 != null ? n0.normalize() : faceNormal,
                n1 != null ? n1.normalize() : faceNormal,
                n2 != null ? n2.normalize() : faceNormal
        };
    }

    public Triangle(Vector3D v0, Vector3D v1, Vector3D v2, Color color) {
        this(v0, v1, v2,
                v1.subtract(v0).cross(v2.subtract(v0)).normalize(), // same normal for all
                v1.subtract(v0).cross(v2.subtract(v0)).normalize(),
                v1.subtract(v0).cross(v2.subtract(v0)).normalize(),
                color);
    }

    private static Vector3D calculateCentroid(Vector3D v0, Vector3D v1, Vector3D v2) {
        return new Vector3D(
                (v0.getX() + v1.getX() + v2.getX()) / 3.0,
                (v0.getY() + v1.getY() + v2.getY()) / 3.0,
                (v0.getZ() + v1.getZ() + v2.getZ()) / 3.0
        );
    }

    public Vector3D[] getVertices() {
        return vertices;
    }

    public Vector3D[] getNormals() {
        return normals;
    }

    @Override
    public Intersection intersect(Ray ray) {
        triangleTests++;

        Vector3D v0 = vertices[0], v1 = vertices[1], v2 = vertices[2];
        Vector3D n0 = normals[0], n1 = normals[1], n2 = normals[2];

        Vector3D rayDir = ray.getDirection();
        Vector3D h = rayDir.cross(edge2);
        double determinant = edge1.dot(h);

        // If determinant is near zero, ray is parallel to triangle
        if (Math.abs(determinant) < EPSILON) return null;

        double invDet = 1.0 / determinant;
        Vector3D s = ray.getOrigin().subtract(v0);
        double u = invDet * s.dot(h);

        if (u < 0.0 || u > 1.0) return null;

        Vector3D q = s.cross(edge1);
        double v = invDet * rayDir.dot(q);

        if (v < 0.0 || (u + v) > 1.0) return null;

        double t = invDet * edge2.dot(q);

        if (t > EPSILON) {
            Vector3D intersectionPoint = ray.getOrigin().add(rayDir.multiply(t));

            // Barycentric coordinate w
            double w = 1.0 - u - v;

            // Interpolate the normal using barycentric coordinates
            Vector3D interpolatedNormal;
            if (normals[0].equals(normals[1]) && normals[0].equals(normals[2])) {
                interpolatedNormal = normals[0]; // flat
            } else {
                interpolatedNormal = normals[0].multiply(w)
                        .add(normals[1].multiply(u))
                        .add(normals[2].multiply(v));
                // Optionally normalize
                interpolatedNormal = interpolatedNormal.normalize();
            }

            return new Intersection(t, intersectionPoint, interpolatedNormal, this);
        }

        return null;
    }

    @Override
    public BoundingBox getBoundingBox() {
        Vector3D min = new Vector3D(
                Math.min(vertices[0].getX(), Math.min(vertices[1].getX(), vertices[2].getX())),
                Math.min(vertices[0].getY(), Math.min(vertices[1].getY(), vertices[2].getY())),
                Math.min(vertices[0].getZ(), Math.min(vertices[1].getZ(), vertices[2].getZ()))
        );
        Vector3D max = new Vector3D(
                Math.max(vertices[0].getX(), Math.max(vertices[1].getX(), vertices[2].getX())),
                Math.max(vertices[0].getY(), Math.max(vertices[1].getY(), vertices[2].getY())),
                Math.max(vertices[0].getZ(), Math.max(vertices[1].getZ(), vertices[2].getZ()))
        );
        return new BoundingBox(min, max);
    }
}
