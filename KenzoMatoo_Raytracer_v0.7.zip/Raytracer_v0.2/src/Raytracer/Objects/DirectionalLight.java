package Raytracer.Objects;

import Raytracer.Intersection;
import Raytracer.Vector3D;

import java.awt.*;

public class DirectionalLight extends Light{
    private Vector3D direction;

    public DirectionalLight(Vector3D direction, Color color, double intensity) {
        super(Vector3D.ZERO(), color, intensity);
        setDirection(direction);
    }

    public Vector3D getDirection() {
        return direction;
    }

    public void setDirection(Vector3D direction) {
        this.direction = direction.normalize();
    }

    @Override
    public double getNDotL(Intersection intersection) {
        // Calculate N · L, where L is the inverse of the light direction
        Vector3D L = direction.negate(); // Light direction is opposite to the directional vector
        return Math.max(intersection.getNormal().dot(L), 0.0); // Use instance dot
    }
}
