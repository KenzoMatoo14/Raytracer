import java.awt.Color;

public class Light {
    private Vector3D direction; // Only for directional light
    private Color color;
    private double intensity;

    public Light(Vector3D direction, Color color, double intensity) {
        this.direction = direction.normalize();
        this.color = color;
        this.intensity = intensity;
    }

    public Vector3D getDirection() {
        return direction;
    }

    public Color getColor() {
        return color;
    }

    public double getIntensity() {
        return intensity;
    }
}
