import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Raytracer {

    private Scene scene;
    private Camera camera;

    // Constructor
    public Raytracer(Scene scene, Camera camera) {
        this.scene = scene;
        this.camera = camera;
    }

    // Trace a single ray and return a color
    public Color traceRay(Ray ray) {
        Intersection intersection = scene.intersect(ray, camera.getNear(), camera.getFar());

        if (intersection != null) {
            Vector3D normal = intersection.getNormal().normalize();
            Color objectColor = intersection.getObject().getColor();

            int r = 0, g = 0, b = 0;

            for (Light light : scene.getLights()) {
                Vector3D lightDir = light.getDirection().negate().normalize(); // from surface toward light
                double dot = Math.max(0.0, normal.dot(lightDir)); // Lambertian term

                r += (int)(light.getColor().getRed() * objectColor.getRed() / 255.0 * light.getIntensity() * dot);
                g += (int)(light.getColor().getGreen() * objectColor.getGreen() / 255.0 * light.getIntensity() * dot);
                b += (int)(light.getColor().getBlue() * objectColor.getBlue() / 255.0 * light.getIntensity() * dot);
            }

            return new Color(Math.min(255, r), Math.min(255, g), Math.min(255, b));
        }

        return Color.BLACK;
    }

    // Render the scene and save to an image
    public void render(int width, int height, String filename) {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        System.out.println("Rendering scene...");

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                double normX = (double) x / (width - 1);
                double normY = (double) y / (height - 1);

                Ray ray = camera.generateRay(normX, normY);
                Color color = traceRay(ray);

                image.setRGB(x, y, color.getRGB());
            }
        }

        // Save image to file
        try {
            File output = new File(filename);
            ImageIO.write(image, "png", output);
            System.out.println("Image saved as " + filename);
        } catch (IOException e) {
            System.err.println("Failed to save image: " + e.getMessage());
        }
    }


    // Main method to run the raytracer
    public static void main(String[] args) {
        // Create a scene
        Scene scene = new Scene();

        // Define camera parameters
        Vector3D cameraPos = new Vector3D(0, 0, 0);
        Vector3D lookAt = new Vector3D(0, 0, -1);
        Vector3D up = new Vector3D(0, 1, 0);
        double fov = 60;  // Field of view in degrees
        double aspectRatio = 1; // Example: width / height (adjust as needed)
        double near = 0.1;  // Near plane (prevent extreme closeness)
        double far = 400;

        // Create a camera at (0,0,0) looking towards -Z
        Camera camera = new Camera(cameraPos, lookAt, up, fov, aspectRatio, near, far);

        // Add objects to the scene (Positioned to match the reference image)

        //scene.addObject(new Sphere(new Vector3D(0, 3, -10), 1, Color.RED)); // Larger red sphere
        //scene.addObject(new Sphere(new Vector3D(6, 4, -12), 1, Color.BLUE));// Larger blue sphere

        /*
        scene.addObject(new Triangle(
                new Vector3D(0, 4, -6),
                new Vector3D(5, 3, -8),
                new Vector3D(4, 8, -10),
                Color.GREEN));
        scene.addObject(new Triangle(
                new Vector3D(0, 4, -6),
                new Vector3D(5, 3, -8),
                new Vector3D(2, 2, -10),
                Color.GREEN));
        */

        /*
        scene.addObject(new Model3D(
                new Vector3D(0, 0, -7),
                new Triangle[]{
                        new Triangle(
                                new Vector3D(0, 4, -6),
                                new Vector3D(5, 3, -8),
                                new Vector3D(4, 8, -10),
                                Color.GREEN),
                        new Triangle(
                                new Vector3D(0, 4, -6),
                                new Vector3D(5, 3, -8),
                                new Vector3D(2, 2, -8),
                                Color.GREEN)},
                Color.GREEN));
         */


        String pathToOBJ = "src/Models/Ring.obj"; // adjust as needed
        Vector3D modelPosition = new Vector3D(0, -2, -5);  // where to place the model
        Color modelColor = Color.RED;

        Model3D model = ObjectReader.readOBJ(pathToOBJ, modelPosition, modelColor);
        scene.addObject(model);

        String pathToOBJ1 = "src/Models/Cube.obj"; // adjust as needed
        Vector3D modelPosition1 = new Vector3D(0, 2, -5);  // where to place the model
        Color modelColor1 = Color.RED;

        Model3D model1 = ObjectReader.readOBJ(pathToOBJ1, modelPosition1, modelColor1);
        scene.addObject(model1);

        String pathToOBJ2 = "src/Models/CubeQuad.obj"; // adjust as needed
        Vector3D modelPosition2 = new Vector3D(2, 0, -5);  // where to place the model
        Color modelColor2 = Color.GREEN;

        Model3D model2 = ObjectReader.readOBJ(pathToOBJ2, modelPosition2, modelColor2);
        scene.addObject(model2);

        String pathToOBJ3 = "src/Models/SmallTeapot.obj"; // adjust as needed
        Vector3D modelPosition3 = new Vector3D(-1, 0, -5);  // where to place the model
        Color modelColor3 = Color.BLUE;

        Model3D model3 = ObjectReader.readOBJ(pathToOBJ3, modelPosition3, modelColor3);
        scene.addObject(model3);


        /*
        String pathToOBJ4 = "src/Models/shark1.obj"; // adjust as needed
        Vector3D modelPosition4 = new Vector3D(0, 0, -200);  // where to place the model
        Color modelColor4 = Color.RED;

        Model3D model4 = ObjectReader.readOBJ(pathToOBJ4, modelPosition4, modelColor4);
        scene.addObject(model4);
         */

        scene.addLight(new Light(new Vector3D(0, 2, -1), Color.WHITE, 2.0));

        // Create raytracer
        Raytracer raytracer = new Raytracer(scene, camera);
        // Render and save to an image
        raytracer.render(800, 800, "output.png");
    }
}
